export interface Student {
  id?: number;
  firstName: string;
  lastName: string;
  email: string;
  dateOfBirth: string;
  grade: string;
  studentId: string;
  contactNumber: string;
}